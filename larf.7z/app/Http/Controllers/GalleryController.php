<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;

class GalleryController extends Controller
{
    public function api(){
        $client = new Client();
        $res = $client->request('post', 'http://ws.audioscrobbler.com/2.0/?method=album.getinfo&api_key=bd726c4130a2c45a813a773b495445a2&artist=Cher&album=Believe&format=json');
        $res=$res->getbody();
        //echo($res);
        $qwe=$this->convertToJson($res);
        echo($qwe);
    }  

    public function convertToJson($res){
        $wer = json_decode($res);
        $ert = $wer->album->image[1]->size;
        return $ert;
    }  
}
// bd726c4130a2c45a813a773b495445a2